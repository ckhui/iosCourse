//
//  AppDelegate.h
//  Day3-MiniBrowser
//
//  Created by NEXTAcademy on 10/19/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

