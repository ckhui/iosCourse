//
//  Comment+CoreDataClass.m
//  BookFace
//
//  Created by NEXTAcademy on 11/4/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import "Comment+CoreDataClass.h"
#import "Book+CoreDataClass.h"
@implementation Comment

@end
