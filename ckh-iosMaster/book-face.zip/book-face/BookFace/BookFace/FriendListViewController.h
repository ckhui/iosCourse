//
//  FriendListViewController.h
//  BookFace
//
//  Created by NEXTAcademy on 11/3/16.
//  Copyright © 2016 ckhui. All rights reserved.
//


#import "BaseViewController.h"

@interface FriendListViewController : BaseViewController

@end
