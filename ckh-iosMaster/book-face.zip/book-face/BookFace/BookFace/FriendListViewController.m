//
//  FriendListViewController.m
//  BookFace
//
//  Created by NEXTAcademy on 11/3/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import "FriendListViewController.h"
#import "AppDelegate.h"
#import "User+CoreDataClass.h"
#import "ProfileViewController.h"
#import "AddFriendViewController.h"

@interface FriendListViewController () <UITableViewDataSource, UITableViewDelegate, NSFetchedResultsControllerDelegate>

@property (weak, nonatomic) IBOutlet UITableView *listFriendTableView;

@property NSArray *users;
@property User *showUserProfile;


@property (nonatomic, strong) NSFetchedResultsController *fetchedResultsController;
@property NSManagedObjectContext *moc;

@end

@implementation FriendListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //init
    self.listFriendTableView.dataSource = self;
    self.listFriendTableView.delegate = self;
    
    
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    self.mainContainer = [appdelegate persistentContainer];
    self.moc = self.mainContainer.viewContext;
    
    self.moc = [appdelegate persistentContainer].viewContext;
    
    //first time, load data and save to core data
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    if(![def objectForKey:@"load data"]){
        NSLog(@"loading Data");
        
        NSString *inputData = [[NSBundle mainBundle] pathForResource:@"users" ofType:@"plist"];
        NSArray *users = [NSArray arrayWithContentsOfFile:inputData];
        
        for (NSString *name in users){
            
            // Create NSManagedObject subclass
            // Pay attention to the NSManagedObjectContext
            User *user = [NSEntityDescription insertNewObjectForEntityForName:@"User" inManagedObjectContext:self.moc];
            user.name = name;
            if (rand()%10 == 0){
                user.isFriend = YES;
            }
//            NSManagedObjectContext *newContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
            
//            [self.moc deleteObject:user];
            
            
        }
        
        NSError *error;
        // save the object which belong / created / fetched using following context
        if(![self.moc save:&error]){
            NSLog(@"Load data error: %@",error);
        }
        [def setObject:@"Done" forKey:@"load data"];
    }
    
    [self setupFetchResultController];
    
    //[self makeFriend];
    
    //search bar at the top
    //sort friend base on number of book recommender
    //filter base on name
    
}

- (void)setupFetchResultController {
    
    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"User"];
    NSSortDescriptor *sortByXXX = [[NSSortDescriptor alloc]initWithKey:@"name" ascending:YES];
    request.sortDescriptors = @[sortByXXX];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"isFriend == YES"];
    request.predicate = predicate;
    
    self.fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:self.moc sectionNameKeyPath:nil cacheName:nil];
    NSError *fetchError;
    self.fetchedResultsController.delegate = self;
    [self.fetchedResultsController performFetch:&fetchError];
    
    if (fetchError) {
        NSLog(@"Failed to fetch result");
    }
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    //load data from core data
    [self.listFriendTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


 #pragma mark - Navigation

 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
     if([segue.identifier isEqualToString:@"showProfile"]){
         ProfileViewController *destination = [segue destinationViewController];
         destination.userProfile = self.showUserProfile;
         
         // pass NSPersistentContainer
         // To guarntee it called from single source and single thread
         destination.mainContainer = self.mainContainer;
     }
     if([segue.identifier isEqualToString:@"showAddFreindPage"]){
         AddFriendViewController *destination = [segue destinationViewController];
         destination.mainContainer = self.mainContainer;
     }
     
     
 }


#pragma mark - TabelViewDatasource
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"friendCell"];
    
    // old way
//    User *user = [self.users objectAtIndex:indexPath.row];
    
    // nsfetchedresultscontroller
    User *user = [self.fetchedResultsController objectAtIndexPath:indexPath];
    
    cell.textLabel.text = user.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Book :%ld",(long)user.read.count];
    
    return cell;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    // old way
//    return self.users.count;
    
    // nsfetchedresultscontroller way
    NSLog(@"asdasd %d", self.fetchedResultsController.fetchedObjects.count);
    
    return self.fetchedResultsController.fetchedObjects.count;
}


#pragma mare - tableviewDelegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    self.showUserProfile = [self.users objectAtIndex:indexPath.row];
    
    self.showUserProfile = [self.fetchedResultsController.fetchedObjects objectAtIndex:indexPath.row];
    
    [self performSegueWithIdentifier:@"showProfile" sender:self];
    
}

#pragma mark - function
//- (void) loadUser{
//    
//    return;
//    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"User"];
//    
//    NSSortDescriptor *sortByXXX = [[NSSortDescriptor alloc]initWithKey:@"name" ascending:YES];
//    
//    request.sortDescriptors = @[sortByXXX];
//    
//    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"isFriend == YES"];
//    
//    request.predicate = predicate;
//
//    
//    NSError *error = nil;
//    
//    
//    self.users = [[self.moc executeFetchRequest:request error:&error] mutableCopy];
//    
//    if (!error){
//        [self.listFriendTableView reloadData];
//    }else{
//        NSLog(@"load team error :%@",error);
//    }
//    
//}

- (void) makeFriend{
    
}

#pragma mark - NSFetchedResultsController Delegate

- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(nullable NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(nullable NSIndexPath *)newIndexPath {
    
    NSLog(@" path ----- > %@" ,indexPath);
    NSLog(@" newpath ----- > %@" ,newIndexPath);
    
    switch (type) {
        case NSFetchedResultsChangeDelete:
        {
            [self.listFriendTableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
            break;
        case NSFetchedResultsChangeInsert:
        {
           [self.listFriendTableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
            break;
        case NSFetchedResultsChangeMove:
        {
            [self.listFriendTableView moveRowAtIndexPath:indexPath toIndexPath:newIndexPath];
        }
            
            break;
        case NSFetchedResultsChangeUpdate:
        {
            [self.listFriendTableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
            break;
        default:
            break;
    }
    

}













@end
