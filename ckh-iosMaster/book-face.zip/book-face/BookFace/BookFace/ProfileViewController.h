//
//  ProfileViewController.h
//  BookFace
//
//  Created by NEXTAcademy on 11/3/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import "BaseViewController.h"
#import "User+CoreDataClass.h"

@interface ProfileViewController : BaseViewController

@property User *userProfile;
@end
