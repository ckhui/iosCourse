//
//  BaseViewController.h
//  BookFace
//
//  Created by NEXTAcademy on 11/4/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import <UIKit/UIKit.h>
@import CoreData;

@interface BaseViewController : UIViewController
@property (nonatomic, strong) NSPersistentContainer *mainContainer;
@end
