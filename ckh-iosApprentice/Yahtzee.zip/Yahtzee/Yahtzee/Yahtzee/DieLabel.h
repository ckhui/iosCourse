//
//  DieLabel.h
//  Yahtzee
//
//  Created by NEXTAcademy on 10/27/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DieLabel;
@protocol  DieLabelDelegate <NSObject>

- (void) DieLabel:(DieLabel *)dieLabel isSelected:(bool)isSelected;

@end

@interface DieLabel : UILabel
@property (nonatomic, assign)id<DieLabelDelegate> delegate;

@property (nonatomic,assign) bool firstRound;
//3. roll the die
- (void)roll;

- (void) resetDice;

@end


