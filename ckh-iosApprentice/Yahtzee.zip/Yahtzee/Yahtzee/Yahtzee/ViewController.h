//
//  ViewController.h
//  Yahtzee
//
//  Created by NEXTAcademy on 10/27/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

