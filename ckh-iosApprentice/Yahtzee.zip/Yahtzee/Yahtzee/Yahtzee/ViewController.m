//
//  ViewController.m
//  Yahtzee
//
//  Created by NEXTAcademy on 10/27/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import "ViewController.h"
#import "DieLabel.h"
#import "ScoreTableViewCell.h"

@interface ViewController () <DieLabelDelegate, UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) IBOutletCollection(DieLabel) NSArray *allDice;
@property (weak, nonatomic) IBOutlet UIButton *rollButton;
@property (weak, nonatomic) IBOutlet UILabel *gatherBox;


@property (nonatomic,assign) int round;
@property (nonatomic,assign) int playerNumber;
@property (nonatomic,assign) int roundNumber;
@property (nonatomic,assign) int savedDice;

@property (weak, nonatomic) IBOutlet UITableView *scroreTableView;

@property (strong,nonatomic) NSMutableArray * allPlayerScore;

//6. score
@property (strong,nonatomic) NSArray *scoreType;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.scroreTableView.dataSource = self;
    self.scroreTableView.delegate =self;
    
    //S1. gatherDice
    self.gatherBox.userInteractionEnabled = YES;
     UITapGestureRecognizer *gatherBoxTapGasture = [[ UITapGestureRecognizer alloc ] initWithTarget:self action:@selector(onGatherBoxTapped:)];
    [self.gatherBox addGestureRecognizer:gatherBoxTapGasture];
    
    //6. score
    self.scoreType = [NSArray arrayWithObjects:@"Aces",@"Twos",@"Threes",@"Fours",@"Fives",@"Sixes",@"Three Of A Kind",@"Four Of A Kind",@"Full House",@"Small Straight",@"Large Straight",@"Yahtzee",@"Chance",@"custom1",@"custom2", nil];
    
    
    

    
    //init
    [self resetGame];
    
    //2. label -> 1 and backgorund
    for (DieLabel *die in self.allDice){
        die.text = @"1";
        die.backgroundColor = [UIColor redColor];
        
        //2. |DieLabel| delegate
        die.delegate = self;
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) resetGame{
    self.round = 0;
    self.playerNumber = 1;
    self.roundNumber = 0;
    self.savedDice = 0;
    
    self.allPlayerScore = [NSMutableArray new];
    //NSMutableArray *scoreName = [NSMutableArray arrayWithObjects:@"Round 1", @"Round 2", @"Round 3", @"Round 4", @"Round 5", @"Round 6", @"Round 7", @"Round 8", @"Round 9", @"Round 10", nil];
    
    //for(NSString *round in scoreName)
    for(NSString *round in self.scoreType){
        NSMutableArray *eachRound = [NSMutableArray new];
        [eachRound addObject:round];
        [eachRound addObject:@""];
        [eachRound addObject:@""];
        [self.allPlayerScore addObject:eachRound];
    }
}

//4. roll the dice
- (IBAction)onRollButtonPressed:(id)sender {
    if(self.savedDice ==5 || self.round ==3){
        //dont allow to roll untill score save
        
        //[self nextPlayerTurnAtRound:self.roundNumber CurrentPlayer:self.playerNumber];
        //[self.scroreTableView reloadData];
        return;
    }
    
    
    NSLog(@"\t\tRound : %d",self.round);
    //max 3 round
    self.round += 1;
    for (DieLabel *die in self.allDice){
        [die roll];
    }
    
    if (self.round == 3){
        [self.rollButton setTitle:@"EndTurn" forState:UIControlStateNormal];
        //[self nextPlayerTurnAtRound:self.roundNumber CurrentPlayer:self.playerNumber];
        //[self.scroreTableView reloadData];
    }
}

- (void) nextPlayerTurnAtRound:(int) scoreType CurrentPlayer:(int)playerNumber{
    
    //get score (sum)
    NSString *score = [self getScore:scoreType];
    
    //update score
    [[self.allPlayerScore objectAtIndex:scoreType] replaceObjectAtIndex:playerNumber withObject:score];
    
    if(playerNumber == 1){
        self.playerNumber = 2;
    }
    
    else if(playerNumber == 2){
        self.playerNumber = 1;
        self.roundNumber += 1;
    }
    NSLog(@"\t\t\t Next Player");
    
    //reset dice to first round
    for (DieLabel *die in self.allDice){
        [die resetDice];
    }
    [self.rollButton setTitle:@"Roll" forState:UIControlStateNormal];
    self.round = 0;
    self.savedDice = 0;
    
    if (self.roundNumber == 10)
    {
        NSLog(@"\t\t End game");
        //reset
        self.roundNumber = 0 ;
    }
}

- (NSString *) getScore:(int)type{
    
    //get score
    NSInteger score = 0 ;
    NSInteger sum = 0;
    
    //get dice occurance
    NSMutableArray *diceGot = [NSMutableArray arrayWithObjects:@(0),@(0),@(0),@(0),@(0),@(0),@(0), nil];
    
    NSLog(@"%@",diceGot);
    //get all dice
    NSMutableArray *DiceValues = [NSMutableArray new];
    for (DieLabel *die in self.allDice){
        int num = [die.text intValue];
        diceGot[num] = @(1);
        
        [DiceValues addObject:die.text];
        sum += [die.text intValue];
    }
    
   NSLog(@"%@",diceGot);
    
    NSCountedSet *diceCounterset = [[NSCountedSet alloc] initWithArray:DiceValues];
    
    //get number of count for each number
    NSMutableArray *occurancePattern = [NSMutableArray array];
    for (NSNumber *num in diceCounterset) {
        //NSDictionary *dict = @{@"number":num, @"count":@([diceCounterset countForObject:num])};
        [occurancePattern addObject:@([diceCounterset countForObject:num])];
    }
    //NSArray *final = [occurancePattern sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"number" ascending:YES ]]];
    NSArray *pattern = [occurancePattern sortedArrayUsingSelector: @selector(compare:)];
    pattern = [[pattern reverseObjectEnumerator] allObjects];
    //NSLog(@"%@",pattern);
    
    
    //get selected type score
    NSString *scoreType = [self.scoreType objectAtIndex:type];
    
    //implement game rule (score calculation)
    //@"Aces",@"Twos",@"Threes",@"Fours",@"Fives",@"Sixes",@"Three Of A Kind",@"Four Of A Kind",@"Full House",@"Small Straight",@"Large Straight",@"Yahtzee",@"Chance",@"custom1",@"custom2"
    if([scoreType isEqualToString:@"Aces"]){
        score = [diceCounterset countForObject:@"1"] * 1;
    }
    else if([scoreType isEqualToString:@"Twos"]){
        score = [diceCounterset countForObject:@"2"] * 2;
    }
    else if([scoreType isEqualToString:@"Threes"]){
        score = [diceCounterset countForObject:@"3"] * 3;
    }
    else if([scoreType isEqualToString:@"Fours"]){
        score = [diceCounterset countForObject:@"4"] * 4;
    }
    else if([scoreType isEqualToString:@"Fives"]){
        score = [diceCounterset countForObject:@"5"] * 5;
    }
    else if([scoreType isEqualToString:@"Sixes"]){
        score = [diceCounterset countForObject:@"6"] * 6;
    }
    else if([scoreType isEqualToString:@"Three Of A Kind"]){
        if ([pattern[0] intValue] >= 3){
            score = sum;
        }
        
    }
    else if([scoreType isEqualToString:@"Four Of A Kind"]){
        if ([pattern[0] intValue] >= 4){
            score = sum;
        }

    }
    else if([scoreType isEqualToString:@"Full House"]){
        if ([pattern[0] intValue] == 5){
            score = 25;
        }
        else if ([pattern[0] intValue] == 3 && [pattern[1] intValue] == 2){
            score = 25;
        }
    }
    else if([scoreType isEqualToString:@"Small Straight"]){
        
        if([diceGot[3] intValue] + [diceGot[4] intValue] ==2){
            if([diceGot[1] intValue] + [diceGot[2] intValue] ==2){
                score = 30;
            }
            else if([diceGot[2] intValue] + [diceGot[5] intValue] ==2){
                score = 30;
            }
            else if([diceGot[5] intValue] + [diceGot[6] intValue] ==2){
                score = 30;
            }
        }
    }
    else if([scoreType isEqualToString:@"Large Straight"]){
        if([diceGot[2] intValue] + [diceGot[3] intValue] + [diceGot[4] intValue] == 3){
            if([diceGot[1] intValue] + [diceGot[5] intValue] ==2){
                score = 40;
            }
            else if([diceGot[5] intValue] + [diceGot[6] intValue] ==2){
                score = 40;
            }
        }
    }
    else if([scoreType isEqualToString:@"Yahtzee"]){
        if ([pattern[0] intValue] == 5){
            score = 50;
        }
    }
    else if([scoreType isEqualToString:@"Chance"]){
        score = sum;
    }
    else{
        NSLog(@"Unknow type");
    }
    
    return [NSString stringWithFormat:@"%ld",(long)score];
}


- (void) onGatherBoxTapped:(UITapGestureRecognizer *)tapGesture{
    NSLog(@"Gather Box TAPPED");
}

#pragma mark - UITableView datasource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ScoreTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"scoreCell"];
    if (indexPath.row == 0){
        //display heading
        cell.nameLabel.text = @"Round";
        cell.player1.text = @"Player 1";
        cell.player2.text = @"Player 2";
    }
    else{
        //display Score
        NSMutableArray *playersScore = [self.allPlayerScore objectAtIndex:indexPath.row - 1];
        cell.nameLabel.text = playersScore[0];
        cell.player1.text = playersScore[1];
        cell.player2.text = playersScore[2];
    }
    
    //    NSLog(@"%@ , %@ , %@",cell.playersScore[0],cell.playersScore[1],cell.playersScore[2]);
    
    return cell;
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.allPlayerScore.count  + 1;
}


#pragma mark - UItableView Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *score = [[self.allPlayerScore objectAtIndex:indexPath.row -1] objectAtIndex:self.playerNumber];
    NSLog(@"ScoreType = %@ p=%d score=%@",[self.scoreType objectAtIndex:indexPath.row - 1],self.playerNumber,score);
    
    if ([score isEqualToString:@""]){
        NSLog(@"canScore");
        //save score in this index
        
        //save score
        [self nextPlayerTurnAtRound:(int)(indexPath.row - 1) CurrentPlayer:self.playerNumber];
        [self.scroreTableView reloadData];
        
    }
    else{
        NSLog(@"alreadyScore");
        //dont allow score to save
        
    }
    
    
    
    
}

#pragma mark - die Delegate

- (void) DieLabel:(DieLabel *)dieLabel isSelected:(bool)isSelected{
    
    if(isSelected){
        self.savedDice += 1;
    }
    else{
        self.savedDice -= 1;
    }
    
    //if all dice saved
    //button : roll -> nextPlayerTurn
    if(self.savedDice == 5 || self.round == 3){
        [self.rollButton setTitle:@"EndTurn" forState:UIControlStateNormal];
    }
    else{
        [self.rollButton setTitle:@"Roll" forState:UIControlStateNormal];
    }
}

@end
