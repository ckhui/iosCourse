//
//  DieLabel.m
//  Yahtzee
//
//  Created by NEXTAcademy on 10/27/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import "DieLabel.h"
@interface DieLabel() <UIGestureRecognizerDelegate>

@property (nonatomic,assign)bool selected;

@end

@implementation DieLabel

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        //5. default: no selected
        self.selected = NO;
        
        self.firstRound = YES;
        
        //2. user interaction enable
        self.userInteractionEnabled = YES;
        
        //2. label tapped function
        UITapGestureRecognizer *tapGasture = [[ UITapGestureRecognizer alloc ] initWithTarget:self action:@selector(onLabelTapped:)];
        
        [self addGestureRecognizer:tapGasture];
    }
    return self;
}

//2. label tapped function
- (void) onLabelTapped:(UITapGestureRecognizer *)tapGesture{
    NSLog(@"Die label tapped : %@", self.text);
    
    if (self.firstRound) {
        NSLog(@"First round, cannot select die");
        return;
    }
    else{
        //5. select / not select
        self.selected = !self.selected;
        //5. seleted ->green , else -> red
        if(self.selected){
            self.backgroundColor = [UIColor greenColor];
            //self.textColor = [UIColor greenColor];
        }
        else{
            self.backgroundColor = [UIColor redColor];
            //self.textColor = [UIColor redColor];
        }
    }
    
    //delegate
    //if all dice are saved, process to next player
    [self.delegate DieLabel:self isSelected:self.selected];
}

//3. roll the die
- (void)roll{
    self.firstRound = NO;
    if(!self.selected){
        int rand = arc4random()%6+1;
        NSLog(@"Die rolled : %d", rand);
        self.text = [NSString stringWithFormat:@"%d", rand];
        
        //S3. image
        //[self showDiceImage:rand];
    }
}

- (void) resetDice{
    self.text = @"1";
    self.backgroundColor = [UIColor redColor];
    self.firstRound = YES;
    self.selected = NO;
    
    //S3. image
    //[self showDiceImage:1];
}

//S3. image
- (void)showDiceImage: (int) number{
    
    UIImage *diceImage = [UIImage imageNamed:[NSString stringWithFormat:@"dice%d",number]];
    self.backgroundColor = [UIColor colorWithPatternImage:diceImage];
    
}
@end
