//
//  detailedViewController.h
//  pokedex
//
//  Created by NEXTAcademy on 10/25/16.
//  Copyright © 2016 ckhui. All rights reserved.
//

#import "ViewController.h"
#import "Pokemon.h"

@interface detailedViewController : ViewController

@property (strong, nonatomic) Pokemon *pokemon;
@end
